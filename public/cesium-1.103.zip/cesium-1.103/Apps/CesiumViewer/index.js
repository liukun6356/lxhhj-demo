window.CESIUM_BASE_URL = ".";
