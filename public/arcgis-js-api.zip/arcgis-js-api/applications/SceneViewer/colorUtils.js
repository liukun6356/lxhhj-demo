/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports"],(function(t){"use strict";function e(t){return t.isBright}t.isBright=e,Object.defineProperty(t,Symbol.toStringTag,{value:"Module"})}));
