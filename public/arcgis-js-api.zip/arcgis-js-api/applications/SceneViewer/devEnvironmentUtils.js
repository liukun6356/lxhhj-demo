/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports","../../core/devEnvironmentUtils"],(function(e,n){"use strict";function t(e){return n.isDevEnvironment(e)}function o(e){e=e||globalThis.location.hostname;return[/^zrh-.+?\.esri\.com$/].concat(n.devHostnames).some((n=>null!=e?.match(n)))}e.isDevEnvironment=t,e.isTelemetryDevEnvironment=o,Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})}));
