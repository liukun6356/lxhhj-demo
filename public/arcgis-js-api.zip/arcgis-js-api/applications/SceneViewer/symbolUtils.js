/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports","../../symbols/support/symbolLayerUtils","../../symbols/support/symbolLayerUtils3D"],(function(e,t,o){"use strict";async function s(e){const s=await t.computeObjectLayerResourceSize(e);return o.objectSymbolLayerSizeWithResourceSize(s,e)}e.computeObjectLayerSize=s,Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})}));
