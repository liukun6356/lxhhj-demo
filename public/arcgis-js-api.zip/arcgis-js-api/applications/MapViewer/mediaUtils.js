/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports","../../layers/support/mediaUtils"],(function(e,o){"use strict";async function t(e,t){return o.createDefaultControlPointsGeoreference(e,t)}function r(e){return o.createLocalModeControlPointsGeoreference(e)}e.createDefaultControlPointsGeoreference=t,e.createLocalModeControlPointsGeoreference=r,Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})}));
