/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports"],(function(e){"use strict";var n;e.LengthDimensionMeasureType=void 0,(n=e.LengthDimensionMeasureType||(e.LengthDimensionMeasureType={})).Horizontal="horizontal",n.Vertical="vertical",n.Direct="direct";const i=[e.LengthDimensionMeasureType.Horizontal,e.LengthDimensionMeasureType.Vertical,e.LengthDimensionMeasureType.Direct];e.lengthDimensionMeasureType=i,Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})}));
