/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define((function(){"use strict";class t{constructor(t,i,e,s){this._lastFetchedIndex=0,this._ordered=!1,this.pagesDefinition=null,this._candidates=t,this._known=i,this._ordered=e,this.pagesDefinition=s}}return t}));
