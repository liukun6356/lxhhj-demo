/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports"],(function(e){"use strict";class r{constructor(e,r){this.preLayerQueryCallback=e,this.preRequestCallback=r,this.preLayerQueryCallback||(this.preLayerQueryCallback=e=>{}),this.preRequestCallback||(this.preLayerQueryCallback=e=>{})}}e.FeatureSetQueryInterceptor=r,Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})}));
