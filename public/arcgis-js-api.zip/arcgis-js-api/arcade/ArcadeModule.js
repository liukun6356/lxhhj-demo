/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports"],(function(e){"use strict";class t{constructor(e){this.source=e}}e.ArcadeModule=t,Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})}));
