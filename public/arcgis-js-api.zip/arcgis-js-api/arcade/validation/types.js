/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports"],(function(i){"use strict";var r;i.DiagnosticSeverity=void 0,(r=i.DiagnosticSeverity||(i.DiagnosticSeverity={})).Error="Error",r.Warning="Warning",Object.defineProperty(i,Symbol.toStringTag,{value:"Module"})}));
