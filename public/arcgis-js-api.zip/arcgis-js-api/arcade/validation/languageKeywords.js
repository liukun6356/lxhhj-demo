/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports","../lib/types"],(function(e,t){"use strict";const r=Object.values(t.Keywords),s=["case","catch","debugger","switch","try"];e.arcadeKeywords=r,e.arcadeReservedKeywords=s,Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})}));
