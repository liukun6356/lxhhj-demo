/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["exports","../portal/Portal"],(function(e,t){"use strict";function r(e,r){if(null===e)return r;return new t({url:e.field("url")})}e.getPortal=r,Object.defineProperty(e,Symbol.toStringTag,{value:"Module"})}));
