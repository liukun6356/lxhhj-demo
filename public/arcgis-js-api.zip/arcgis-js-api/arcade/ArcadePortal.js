/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define(["./Dictionary"],(function(t){"use strict";class e extends t{constructor(t){super(),this.declaredClass="esri.arcade.Portal",this.immutable=!1,this.setField("url",t),this.immutable=!0}}return e}));
