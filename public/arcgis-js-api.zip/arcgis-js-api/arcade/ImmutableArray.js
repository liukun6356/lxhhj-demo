/*
All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://js.arcgis.com/4.29/esri/copyright.txt for details.
*/
define((function(){"use strict";class t{constructor(t=[]){this._elements=t}length(){return this._elements.length}get(t){return this._elements[t]}toArray(){const t=[];for(let e=0;e<this.length();e++)t.push(this.get(e));return t}}return t}));
